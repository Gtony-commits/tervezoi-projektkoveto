import{env as e}from"cloudflare:workers";var t=`
  CREATE TABLE IF NOT EXISTS page_comments (
    id TEXT PRIMARY KEY,
    page_key TEXT NOT NULL,
    author_name TEXT NOT NULL,
    body TEXT NOT NULL,
    x_percent REAL NOT NULL,
    y_percent REAL NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT
  )
`,n=`
  CREATE INDEX IF NOT EXISTS idx_page_comments_page_created
  ON page_comments (page_key, created_at DESC)
`,r=`
  CREATE INDEX IF NOT EXISTS idx_page_comments_created
  ON page_comments (created_at DESC)
`;function i(){let t=e.DB;if(!t)throw Error(`A DB adatbázis-kapcsolat nem érhető el.`);return t}async function a(){let e=i();return await e.batch([e.prepare(t),e.prepare(n),e.prepare(r)]),e}var o=`force-dynamic`;function s(e,t=200){return Response.json(e,{status:t,headers:{"Cache-Control":`no-store`}})}async function c(){try{return s({comments:(await(await a()).prepare(`SELECT id, page_key, author_name, body, x_percent, y_percent, created_at, updated_at
         FROM page_comments
         ORDER BY created_at DESC
         LIMIT 250`).all()).results})}catch(e){return s({error:e instanceof Error?e.message:`A kommentek betöltése sikertelen.`},500)}}async function l(e){try{let t=await e.json(),n=String(t.pageKey??``).trim(),r=String(t.authorName??``).trim(),i=String(t.body??``).trim(),o=Number(t.xPercent),c=Number(t.yPercent);if(!n||n.length>160)return s({error:`Érvénytelen oldalhivatkozás.`},400);if(r.length<2||r.length>60)return s({error:`A név 2–60 karakter hosszú lehet.`},400);if(!i||i.length>1200)return s({error:`A komment 1–1200 karakter hosszú lehet.`},400);if(!Number.isFinite(o)||!Number.isFinite(c)||o<0||o>100||c<0||c>100)return s({error:`Érvénytelen kommentpozíció.`},400);let l={id:crypto.randomUUID(),page_key:n,author_name:r,body:i,x_percent:o,y_percent:c,created_at:new Date().toISOString(),updated_at:null};return await(await a()).prepare(`INSERT INTO page_comments
          (id, page_key, author_name, body, x_percent, y_percent, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`).bind(l.id,l.page_key,l.author_name,l.body,l.x_percent,l.y_percent,l.created_at).run(),s({comment:l},201)}catch(e){return s({error:e instanceof Error?e.message:`A komment mentése sikertelen.`},500)}}async function u(e){try{let t=await e.json(),n=String(t.id??``).trim(),r=String(t.authorName??``).trim(),i=String(t.body??``).trim();if(!n||n.length>80)return s({error:`Érvénytelen komment.`},400);if(r.length<2||r.length>60)return s({error:`A név 2–60 karakter hosszú lehet.`},400);if(!i||i.length>1200)return s({error:`A komment 1–1200 karakter hosszú lehet.`},400);let o=new Date().toISOString();return(await(await a()).prepare(`UPDATE page_comments
         SET author_name = ?, body = ?, updated_at = ?
         WHERE id = ?`).bind(r,i,o,n).run()).meta.changes?s({comment:{id:n,author_name:r,body:i,updated_at:o}}):s({error:`A komment nem található.`},404)}catch(e){return s({error:e instanceof Error?e.message:`A komment szerkesztése sikertelen.`},500)}}async function d(e){try{let t=await e.json(),n=String(t.id??``).trim();return!n||n.length>80?s({error:`Érvénytelen komment.`},400):(await(await a()).prepare(`DELETE FROM page_comments WHERE id = ?`).bind(n).run()).meta.changes?s({deleted:!0}):s({error:`A komment nem található.`},404)}catch(e){return s({error:e instanceof Error?e.message:`A komment törlése sikertelen.`},500)}}export{d as DELETE,c as GET,u as PATCH,l as POST,o as dynamic};