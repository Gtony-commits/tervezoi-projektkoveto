export default {
  "bootstrapScriptContent": "import(\"/_next/static/chunks/index-COLY7al1.js\")",
  "clientReferenceDeps": {
    "6894d3222783": {
      "js": [
        "/_next/static/chunks/nina-planner-BCNybEmp.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/index-COLY7al1.js"
      ],
      "css": []
    },
    "4708c832f3c7": {
      "js": [
        "/_next/static/chunks/index-COLY7al1.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "275e3ce4bc6b": {
      "js": [
        "/_next/static/chunks/index-COLY7al1.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "6a106cb4b5a0": {
      "js": [
        "/_next/static/chunks/index-COLY7al1.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "56d484ab4931": {
      "js": [
        "/_next/static/chunks/index-COLY7al1.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "5cf7d6e01c84": {
      "js": [
        "/_next/static/chunks/layout-segment-context-D5hsK9xr.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-COLY7al1.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "c0f4a63e3ed4": {
      "js": [
        "/_next/static/chunks/index-COLY7al1.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "2593fc1a6f04": {
      "js": [
        "/_next/static/chunks/streamed-icons-Bumrcy-j.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/index-COLY7al1.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/_next/static/css/index.DsSYTsT4.css"
      ]
    }
  }
}